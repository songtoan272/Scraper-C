#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
#define BUFFER_SIZE 1000
#define NB_MIME_TYPES 691

size_t write_data(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}


typedef struct typeMIME{
    char *type;
    char *extension;
}TypeMIME;


    int main(void) {
        CURL *curl;
        FILE *fp;
        CURLcode res;
        //int i=0;
        TypeMIME typesMime[NB_MIME_TYPES];
        char *ext, *typeMime, *startExt, *endExt, *startTypeMime, *endTypeMime, *buffer;
        char *url = "https://developer.mozilla.org/fr/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Complete_list_of_MIME_types";
        char *outfilename = "MIME_Types.txt";
        // Download the content of the website who refer the list of mime types
        curl = curl_easy_init();
        if (curl) {
            fp = fopen(outfilename,"wb");
            curl_easy_setopt(curl, CURLOPT_URL, url);
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
            res = curl_easy_perform(curl);
            curl_easy_cleanup(curl);
            fclose(fp);
            printf("File writed\n");
        }
        // Open our file to parse and get type mime and its extension
        fp = fopen(outfilename,"r");
        if(fp == NULL) {
            printf("Impossible d'accéder au fichier\n");
            exit(EXIT_SUCCESS);
        }
        // Get each line of html content
        while((fgets(buffer,BUFFER_SIZE, fp) != NULL)) {
            // Get line where we find an <td><code>. -> the line where we can find the extension
            if (strstr(buffer, "<td><code>.") != NULL && strstr(buffer, ".") != NULL) {
                ext = strstr(buffer, "<td><code>.");
                startExt = ext + strlen("<td><code>");
                endExt = strstr(startExt, "</code>");
                ext = strndup(startExt, endExt - startExt);
                // Some extension have <br>, so we remove it
                if(strstr(ext,"<br>")){
                    endExt = strstr(ext, "<br>");
                    ext = strndup(ext, endExt - ext);
                }
              // nbType++;
            }
            // Same use as for extension but we check here if we dont have a "."
            else if(strstr(buffer, "<td><code>") != NULL && strstr(buffer, ".") == NULL) {
                typeMime = strstr(buffer, "<td><code>");
                startTypeMime = typeMime + strlen("<td><code>");
                endTypeMime = strstr(startTypeMime, "</code>");
                typeMime = strndup(startTypeMime, endTypeMime - startTypeMime);
             // When we get the end of tbody we stop the process
            }else if(strstr(buffer, "</tbody>") != NULL) {
                free(ext);
                free(typeMime);
                break;
            }
            typesMime->extension = ext;
            typesMime->type = typeMime;
            printf("ext : %s \n type : %s\n",typesMime->extension,typesMime->type);
            //printf("extension: %s\ntype mime : %s\n", ext, typeMime);
        }
        fclose(fp);
        return 0;
}
