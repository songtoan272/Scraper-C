#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>


size_t write_data(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    size_t written = fwrite(ptr, size, nmemb, stream);
    return written;
}

int main () {
   // FILE *fp;
   // char str[60];
   CURLcode res;
   CURL *curl = curl_easy_init();
   if(curl) {
   curl_easy_setopt(curl, CURLOPT_URL, "www.stackoverflow.com");
   
   res = curl_easy_perform(curl);
   
   if(!res) {
      /* extract the content-type */
      char *ct = NULL;
      res = curl_easy_getinfo(curl, CURLINFO_CONTENT_TYPE, &ct);
      if(!res && ct) {
         printf("Content-Type: %s\n", ct);
      }
   }
   curl_easy_cleanup(curl);
   }
   
   return(0);
}